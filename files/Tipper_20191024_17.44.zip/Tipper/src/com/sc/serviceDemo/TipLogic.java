package com.sc.serviceDemo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.sc.Notification.NotificationTool;
import com.sc.tool.ActivityComponent;
import com.sc.tool.Preference;
import com.sc.tool.ThreadTool;
import com.sc.tool.ThreadTool.ThreadPram;
import com.sc.tool.TimeTool;
import com.sc.valueTool.ValueAnalyse;

/** 信息提示处理逻辑 */
public class TipLogic
{	
	private static String SetName = "tipper_data";
	
	/** 获取配置信息 */
	public static Preference getSet(Context context)
	{
		Preference Set = new Preference(context, SetName);
		return Set;
	}
	
	/** 信息提示处理逻辑 */
	public static void Doing(Context context)
	{
		if(TimeTool.nowInTimeRegion("17:00:00", "18:00:00"))
		{
			List<String> IdList = getSet(context).Values();
			
			for(String Id : IdList)
			{
				IdDataSave(Id);
				IdCheckTip(context, Id);
			}
		}
	}
	

	
	static int pre = 10000;
	/** Id对应的数据获取与保存逻辑 */
	private static void IdDataSave(String Id)
	{
//		String Url = "" + Id;			
//		String value = Http.Get(Url);
		
		Random random=new Random(System.currentTimeMillis());
		pre = random.nextInt(10000);
		String value = pre + "";
		
		TipData tipData = new TipData(Id);
//		tipData.SaveValue(value);
	}
	
	/** 从Id对应的数据进行检测与提示 */
	private static void IdCheckTip(Context context, String Id)
	{
		TipLog tipLog = new TipLog(Id);
		TipData tipData = new TipData(Id);
		
		List<Float> values = tipData.Values(true);	// 数据
		List<String> names = tipData.Names(false);	// 数据项名称
		
		// 对数据趋势进行解析，提示
		ValueAnalyse analyse = new ValueAnalyse(values, 3);		
		if(analyse.attchMin() || analyse.attchMax())
		{
			boolean isMin = analyse.attchMin();
			
			float vlaueNum = values.get(analyse.Index());
			String name = names.get(analyse.Index());
			
			float avg = analyse.Avg.get(analyse.Index());
			String msg = name + "出现最"+(isMin ? "小" : "大")  + "值:" + vlaueNum + ",  均值 " + avg;
			
			if(!tipLog.fileData.contains(msg))
			{
				ShowNotification(context, Id, msg, tipLog.filePath);
				tipLog.SaveValue(msg);
			}
		}
		
		// ShowText(context, values.toString());
	}
	
	/** 显示通知栏消息 */
	private static void ShowNotification(Context context, String tittle, String content, String FilePath)
	{
		String drawableName = "ic_launcher";
		int icon = ActivityComponent.getId(context, drawableName, "drawable");
		
		Intent intent = new Intent();
		intent.setAction("intent.action.ShowFile");
		intent.putExtra("FilePath", FilePath);
		intent.setPackage(context.getPackageName());	// 用当前应用中的ShowFile打开
		
		NotificationTool.ShowNotification(context, -1, icon, "图标边的文字", tittle, content, intent);
	}
	
	/** 显示提示信息 */
	private static void ShowText(final Context context, final String msg)
	{
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
