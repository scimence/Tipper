﻿
package com.sc.tool;

/** CallBackF.java: ----- 2018-6-6 下午5:50:22 scimence */
public interface CallBackF
{
	// 回调处理逻辑
	public void F(Object... param);
}
